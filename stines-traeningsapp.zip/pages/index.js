import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const weeklyWorkouts = [
  { day: 'Mandag', exercises: ['Squats', 'Hip Thrust'] },
  { day: 'Onsdag', exercises: ['Overhead Press', 'Rows'] },
  { day: 'Fredag', exercises: ['Deadlift', 'Bulgarian Split Squat'] },
];

const progressData = [
  { session: 1, weight: 50 },
  { session: 2, weight: 55 },
  { session: 3, weight: 60 },
];

const dailyMeals = [
  { meal: 'Morgenmad', recommendation: 'Græsk yoghurt med bær og nødder' },
  { meal: 'Frokost', recommendation: 'Rugbrød med laks og avocado' },
  { meal: 'Aftensmad', recommendation: 'Kylling med bagt hokkaido og grøntsager' },
];

export default function Home() {
  const [results, setResults] = useState({});
  const [meals, setMeals] = useState({});
  const [feedback, setFeedback] = useState('');

  const handleInputChange = (exercise, value) => {
    setResults({ ...results, [exercise]: value });
  };

  const handleMealInputChange = (meal, value) => {
    setMeals({ ...meals, [meal]: value });
  };

  const submitResults = () => {
    setFeedback('Fantastisk arbejde, Stine! Næste gang prøver vi at øge vægten med 2,5 kg i Hip Thrust. Husk at få nok protein i din aftensmad for optimal restitution!');
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Stines Trænings- og Kostside</h1>

      <h2 className="text-xl font-semibold mb-2">Ugens træninger</h2>
      {weeklyWorkouts.map((workout) => (
        <div key={workout.day} className="mb-3 border rounded p-4 bg-white shadow">
          <h3 className="font-semibold">{workout.day}</h3>
          <ul className="list-disc list-inside">
            {workout.exercises.map((ex) => (
              <li key={ex}>{ex}</li>
            ))}
          </ul>
        </div>
      ))}

      <h2 className="text-xl font-semibold my-4">Registrer dagens resultater</h2>
      {weeklyWorkouts[0].exercises.map((exercise) => (
        <div key={exercise} className="mb-3 border rounded p-4 bg-white shadow">
          <h3 className="font-semibold">{exercise}</h3>
          <input
            type="text"
            placeholder="Indtast vægt og reps"
            className="border rounded p-2 w-full mt-2"
            onChange={(e) => handleInputChange(exercise, e.target.value)}
          />
        </div>
      ))}

      <button onClick={submitResults} className="mt-4 bg-blue-500 text-white px-4 py-2 rounded">
        Gem træning og kost
      </button>
      {feedback && <div className="mt-4 p-4 bg-green-100 rounded">{feedback}</div>}

      <h2 className="text-xl font-semibold my-4">Anbefalede måltider i dag</h2>
      {dailyMeals.map((meal) => (
        <div key={meal.meal} className="mb-3 border rounded p-4 bg-white shadow">
          <h3 className="font-semibold">{meal.meal}</h3>
          <p>{meal.recommendation}</p>
          <input
            type="text"
            placeholder="Indtast hvad du har spist"
            className="border rounded p-2 w-full mt-2"
            onChange={(e) => handleMealInputChange(meal.meal, e.target.value)}
          />
        </div>
      ))}

      <h2 className="text-xl font-semibold my-4">Din udvikling</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={progressData}>
          <XAxis dataKey="session" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="weight" stroke="#8884d8" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}